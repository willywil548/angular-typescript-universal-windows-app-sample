import { SampleDirective } from './sample.directive';

describe('SampleDirective', () => {
  it('should create an instance', () => {
    const directive = new SampleDirective();
    expect(directive).toBeTruthy();
  });
});
