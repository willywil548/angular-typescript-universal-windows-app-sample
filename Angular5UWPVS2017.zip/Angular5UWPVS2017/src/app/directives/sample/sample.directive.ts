import { Directive } from '@angular/core';

@Directive({
  selector: '[appSample]'
})
export class SampleDirective {

  constructor() { }

}
