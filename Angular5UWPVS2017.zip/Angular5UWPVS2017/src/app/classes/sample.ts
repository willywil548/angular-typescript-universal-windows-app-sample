export class Sample {
}
